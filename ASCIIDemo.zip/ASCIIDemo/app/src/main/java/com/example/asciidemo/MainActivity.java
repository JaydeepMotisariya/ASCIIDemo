package com.example.asciidemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etString;
    private TextView tvValues;
    private Button btnConvert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etString = findViewById(R.id.et_string);
        tvValues = findViewById(R.id.tv_string_to_ascii);
        btnConvert = findViewById(R.id.btn_convert_ascii);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(etString.getText().toString())) {
                    StringBuilder sb = new StringBuilder();
                    String ascString = null;
                    long asciiInt;
                    for (int i = 0; i < etString.getText().toString().length(); i++) {
                        sb.append((int) etString.getText().toString().charAt(i));
//                        char c = etString.getText().toString().charAt(i);
                    }
                    ascString = sb.toString();
                    asciiInt = Long.parseLong(ascString);
                    tvValues.setText(String.valueOf(asciiInt));
                } else {
                    Toast.makeText(MainActivity.this, "Enter String", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    public static long toAscii(String s) {
        StringBuilder sb = new StringBuilder();
        String ascString = null;
        long asciiInt;
        for (int i = 0; i < s.length(); i++) {
            sb.append((int) s.charAt(i));
            char c = s.charAt(i);
        }
        ascString = sb.toString();
        asciiInt = Long.parseLong(ascString);
        return asciiInt;
    }
}